# coding:utf-8

import argparse
import datetime as datetime
import importlib
import ds_database as dd
import ds_queue as dq

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c',
                        '--config',
                        default='ds_config') # 指定配置文件，不要加.py后缀名。
    parser.add_argument('-a',
                        '--action',
                        default='create') # 工作类型
    parser.add_argument('-t',
                        '--task_id',
                        default=0,
                        type=int) # 制定工作相关的task_id
    return parser.parse_args()

def create_task(config):
    task = dd.Task(status=config.TS_NEW)
    task.save()
    queue = dq.Queue(task.id, config.QUEUE) # 创建Job队列
    # select * from source where enabled = True
    sources = dd.Source.select().where(dd.Source.enabled)
    # 创建job并分发到队列
    for source in sources:
        job = dd.Job(task_id=task.id, source_id=source.id, status=config.JS_NEW)
        job.save()
        
        queue.put({'id':job.id, 'source_id':source.id, 'url':source.url})
    task.status = config.TS_INPROGRESS
    task.jobs = len(sources)
    task.save()
    print('Task %d is scheduled with %d jobs.' % (task.id, task.jobs))
    
def view_task(task_id, config):
    r = dd.Task.select().where(dd.Task.id == task_id)
    if r:
        task = r.get()
        if task.status == config.TS_INPROGRESS:
            # 这里看明白后自己再实现一遍
            jobs = dd.Job.select().where(dd.Job.task_id == task_id)
            unfinished = 0
            finished = 0
            failed = 0
            for job in jobs:
                if job.status == config.JS_FINISHED:
                    finished += 1
                elif job.status == config.JS_FAILED:
                    failed += 1
                elif job.status == config.JS_NEW:
                    unfinished += 1
            task.unfinished = unfinished
            task.finished = finished
            task.failed = failed
            if (task.jobs == (finished + failed)) and (unfinished == 0):
                task.status = config.TS_FINISHED
            task.save()
            print('%d jobs for task %d: %d finished, %d failed.' % (task.jobs, task.id, task.finished, task.failed))
        elif task.status == config.TS_FINISHED:
            print('%d jobs for task %d: %d finished, %d failed.' % (task.jobs, task.id, task.finished, task.failed))
        elif task.status == config.TS_NEW:
            print('Task %d not scheduled yet.' % task_id)
    else:
        raise Exception('Task %d not found.' % task_id)

def retry(task_id, config):
    r = dd.Task.select().where(dd.Task.id == task_id)
    if r:
        task = r.get()
        queue = dq.Queue(task.id, config.QUEUE) # 找到task对应的队列
        jobs = dd.Job.select().where((dd.Job.task_id == task_id) & (dd.Job.status != config.JS_FINISHED))
        for job in jobs:
            source = dd.Source.select().where(dd.Source.id == job.source_id).get()
            queue.put({'id':job.id, 'source_id':source.id, 'url':source.url})
            job.status = config.JS_NEW
            job.save()
        task.status = config.TS_INPROGRESS
        task.failed = 0
        task.unfinished = len(jobs)
        task.save()
        print('Retry %d jobs of task %d' % (len(jobs), task_id))
    else:
        raise Exception('Task %d not found.' % task_id)

if __name__ == '__main__':
    ARGS = parse_args()
    CONFIG = importlib.import_module(ARGS.config)
    dd.init_database(CONFIG.DB)
    if ARGS.action == 'create':
        create_task(CONFIG)
    elif ARGS.action == 'view':
        view_task(ARGS.task_id, CONFIG)
    elif ARGS.action == 'retry':
        retry(ARGS.task_id, CONFIG)
    else:
        raise Exception('Unknown action: %s' % ARGS.action)
